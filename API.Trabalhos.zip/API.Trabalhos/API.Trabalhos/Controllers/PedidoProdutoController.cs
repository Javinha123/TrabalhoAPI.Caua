﻿using API.Trabalho.Model;
using API.Trabalho.Repositorio.Interface;
using API.Trabalho.Repositorio.Interface;
using Microsoft.AspNetCore.Mvc;

namespace API.Trabalho.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoProdutoController : ControllerBase
    {
        private readonly IPedidoProdutoRepositorio _PedidoProdutoRepositorio;
        public PedidoProdutoController(IPedidoProdutoRepositorio PedidoProdutoRepositorio)
        {
            _PedidoProdutoRepositorio = PedidoProdutoRepositorio;
        }
        [HttpGet]
        public async Task<ActionResult<List<PedidoProdutoModel>>> BuscarTodosPedidosProduto()
        {
            List<PedidoProdutoModel> PedidoProduto = await _PedidoProdutoRepositorio.BuscarTodosProdutosPedido();
            return Ok(PedidoProduto);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<PedidoProdutoModel>> BuscarPorId(int id)
        {
            PedidoProdutoModel PedidoProduto = await _PedidoProdutoRepositorio.BuscarPorId(id);
            return Ok(PedidoProduto);
        }
        [HttpPost]
        public async Task<ActionResult<PedidoProdutoModel>> Adicionar([FromBody] PedidoProdutoModel pedidoProdutoModel)
        {
            PedidoProdutoModel pedidoProduto = await _PedidoProdutoRepositorio.Adicionar(pedidoProdutoModel);
            return Ok(pedidoProduto);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult<PedidoProdutoModel>> Atualizar(int id, [FromBody] PedidoProdutoModel PedidoProdutoModel)
        {
            PedidoProdutoModel.Id = id;
            PedidoProdutoModel PedidoProduto = await _PedidoProdutoRepositorio.Atualizar(PedidoProdutoModel, id);
            return Ok(PedidoProduto);
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult<PedidoProdutoModel>> Apagar(int id)
        {
            bool apagado = await _PedidoProdutoRepositorio.Apagar(id);
            return Ok(apagado);
        }

    }
}
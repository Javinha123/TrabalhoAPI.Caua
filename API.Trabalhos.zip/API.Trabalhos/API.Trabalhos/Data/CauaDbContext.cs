﻿using Microsoft.EntityFrameworkCore;
using API.Trabalho.Data.Map;
using API.Trabalho.Model;

namespace API.Trabalho.Data
{
    public class CauaDbContext : DbContext
    {
        public CauaDbContext(DbContextOptions<CauaDbContext> options)
            : base(options)
        {
        }
        public DbSet<UsuariosModel> Usuarios { get; set; }
        public DbSet<PedidosModel> Pedidos { get; set; }
        public DbSet<CategoriaModel> Categorias { get; set; }
        public DbSet<ProdutoModel> Produtos { get; set; }
        public DbSet<PedidoProdutoModel> PedidosProduto { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new UsuarioMap());
            base.OnModelCreating(modelBuilder);
        }
    }
}

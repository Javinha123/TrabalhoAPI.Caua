﻿using Microsoft.EntityFrameworkCore;
using API.Trabalho.Data;
using API.Trabalho.Model;
using API.Trabalho.Repositorio.Interface;

namespace API.Trabalho.Repositorio
{
    public class CategoriaRepositorio : ICategoriaRepositorio
    {
        private readonly CauaDbContext _dbContext;

        public CategoriaRepositorio(CauaDbContext avaliacaoDbContext)
        {
            _dbContext = avaliacaoDbContext;
        }

        public async Task<CategoriaModel> BuscarPorId(int id)
        {
            return await _dbContext.Categorias.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<CategoriaModel>> BuscarTodasCategorias()
        {
            return await _dbContext.Categorias.ToListAsync();
        }
        public async Task<CategoriaModel> Adicionar(CategoriaModel categoria)
        {
            await _dbContext.Categorias.AddAsync(categoria);
            await _dbContext.SaveChangesAsync();

            return categoria;
        }
        public async Task<CategoriaModel> Atualizar(CategoriaModel categoria, int id)
        {
            CategoriaModel categoriaPorId = await BuscarPorId(id);
            if (categoriaPorId == null)
            {
                throw new Exception($"Categoria do ID: {id} nao foi encontrado");
            }
            categoriaPorId.Nome = categoria.Nome;
            categoriaPorId.Status = categoria.Status;

            _dbContext.Categorias.Update(categoriaPorId);
            await _dbContext.SaveChangesAsync();
            return categoriaPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            CategoriaModel categoriaPorId = await BuscarPorId(id);
            if (categoriaPorId == null)
            {
                throw new Exception("Categoria nao encontrada");
            }
            _dbContext.Categorias.Remove(categoriaPorId);
            await _dbContext.SaveChangesAsync();

            return true;
        }

        
    }
}

﻿using Microsoft.EntityFrameworkCore;
using API.Trabalho.Data;
using API.Trabalho.Model;
using API.Trabalho.Repositorio.Interface;

namespace API.Trabalho.Repositorio
{
    public class ProdutoRepositorio : IProdutoRepositorio
    {
        private readonly CauaDbContext _dbContext;

        public ProdutoRepositorio(CauaDbContext avaliacaoDbContext)
        {
            _dbContext = avaliacaoDbContext;
        }

        public async Task<ProdutoModel> BuscarPorId(int id)
        {
            return await _dbContext.Produtos.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<ProdutoModel>> BuscarTodosProdutos()
        {
            return await _dbContext.Produtos.ToListAsync();
        }
        public async Task<ProdutoModel> Adicionar(ProdutoModel Produto)
        {
            await _dbContext.Produtos.AddAsync(Produto);
            await _dbContext.SaveChangesAsync();

            return Produto;
        }
        public async Task<ProdutoModel> Atualizar(ProdutoModel Produto, int id)
        {
            ProdutoModel ProdutorPorId = await BuscarPorId(id);
            if (ProdutorPorId == null)
            {
                throw new Exception($"Produto do ID: {id} nao foi encontrado");
            }
            ProdutorPorId.Nome = Produto.Nome;
            ProdutorPorId.Descricao = Produto.Descricao;
            ProdutorPorId.Preco = Produto.Preco;



            _dbContext.Produtos.Update(ProdutorPorId);
            await _dbContext.SaveChangesAsync();
            return ProdutorPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            ProdutoModel ProdutorPorId = await BuscarPorId(id);
            if (ProdutorPorId == null)
            {
                throw new Exception("Produto nao encontrado");
            }
            _dbContext.Produtos.Remove(ProdutorPorId);
            await _dbContext.SaveChangesAsync();

            return true;
        }

        
    }
}

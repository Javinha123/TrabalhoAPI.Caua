﻿
using API.Trabalho.Model;

namespace API.Trabalho.Repositorio.Interface
{

    public interface IPedidoProdutoRepositorio
    {
        Task<List<PedidoProdutoModel>> BuscarTodosProdutosPedido();
        Task<PedidoProdutoModel> BuscarPorId(int id);
        Task<PedidoProdutoModel> Adicionar(PedidoProdutoModel PedidoProduto);
        Task<PedidoProdutoModel> Atualizar(PedidoProdutoModel PedidoProduto, int id);
        Task<bool> Apagar(int id);

    }
}